@echo off
setlocal
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js was not found. Install Node.js 18.17 or later, then run this file again.
  pause
  exit /b 1
)
if not exist ".env" (
  copy ".env.example" ".env" >nul
  echo Created .env from .env.example.
  echo IMPORTANT: Set your rotated AbuseIPDB key and app login credentials.
  notepad .env
  echo Save and close Notepad, then press any key to continue.
  pause >nul
)
if not exist "node_modules" (
  echo Installing dependencies...
  call npm install
  if errorlevel 1 (
    pause
    exit /b 1
  )
)
echo Starting the SOC IP Report Generator...
call npm start
pause
