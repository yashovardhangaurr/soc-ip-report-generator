# SOC Malicious IP Report Generator

A web app that accepts a file containing source IPs, looks up each unique IP in AbuseIPDB, keeps only IPs with an `abuseConfidenceScore` of exactly `100`, defangs those IPs, and generates your SOC email with the finalized bordered, single-column **Source IP** table.

It also supports existing CSV/Excel files with an IP column and a reputation-score column; those files are filtered locally without API calls.

## Security: rotate your API key

The API key previously pasted into chat should be treated as exposed. Revoke/rotate it in AbuseIPDB before using this app and put only the new key in the server environment configuration. Never add the key to `public/index.html`, browser JavaScript, or a GitHub repository.

The app also uses HTTP Basic Authentication. The username and password are supplied in server-side environment variables, so the public service isn't an open relay that anyone can use to consume your AbuseIPDB quota.

AbuseIPDB v2 check endpoint docs: https://docs.abuseipdb.com/

## Host it from your browser (no GitHub or Render desktop installation required)

### 1. Create a private GitHub repository

1. Open https://github.com in Chrome/Edge and sign in.
2. Create a new repository named `soc-ip-report-generator` and choose **Private**.
3. Extract this ZIP on your computer. Open the extracted `soc_ip_report_generator` folder.
4. In the empty repository, choose **Add file → Upload files**. Upload the project files and folders from inside this folder to the repository root. Make sure `server.js`, `package.json`, `render.yaml`, `README.md`, and the `public` folder appear at the top level as shown here. Do **not** upload a `.env` file. `.env.example` contains placeholders only.
5. Commit the uploaded files to the repository's default branch.

### 2. Deploy on Render

1. Open https://render.com in your browser and sign up/sign in.
2. From the Render dashboard, choose **New → Blueprint** and connect your GitHub account/repository, or create a **Web Service** from the repository.
3. If creating a Web Service manually, use:
   - Runtime: `Node`
   - Build command: `npm install`
   - Start command: `npm start`
4. Add these environment variables in Render's service settings:
   - `ABUSEIPDB_API_KEY` = your **newly rotated** AbuseIPDB key
   - `APP_USERNAME` = your chosen login username
   - `APP_PASSWORD` = a long, unique password (not the example placeholder)
5. Save the environment variables and wait for the deployment to finish. Render should provide a URL ending in `onrender.com`.
6. Open the URL in your browser. The browser will ask for the app username/password. Enter the values you set in Render.

If deploying with the included `render.yaml` Blueprint, Render may ask you to enter the three `sync: false` values during setup; provide them there. Never enter your secret key into GitHub.

### 3. Test

Upload a TXT file with one IP per line, or a CSV/Excel file with a source-IP column. The app checks unique valid addresses, waits at least one second between AbuseIPDB requests, shows progress, and filters successful lookups with score exactly `100` into the email. Failed lookups are not treated as clean IPs.

## Local run (optional)

Requires Node.js 18.17 or later. Copy `.env.example` to `.env`, set the rotated API key and login credentials, then run `npm install` and `npm start`. Open http://localhost:3000. The app listens on `127.0.0.1` locally.

## Input, limits, and data flow

- TXT: one IP address per line; blank lines and lines starting with `#` are ignored.
- CSV/Excel IP-only files: headers like `Source IP`, `IP`, `IPAddress`, or IPs in the first column are supported.
- Enriched CSV/Excel files: include an IP column plus a reputation column such as `AbuseConfidenceScore` or `Reputation`.
- The backend validates IPv4/IPv6 addresses and queries up to 300 unique valid IPs per upload; split larger files into batches. API account quotas/rate limits still apply.
- The API key stays on the backend in environment variables. The browser sends source IPs to the app backend, which sends lookup requests to AbuseIPDB.
- Uploaded IPs are indicators from potentially sensitive SOC data. Use a private GitHub repository. Although the app itself is password-protected, be mindful that a hosted service sends submitted IP addresses to AbuseIPDB for reputation checks.
- Render free web services can spin down after 15 minutes of inactivity and may take a little time to wake up. Check the current Render plan details before depending on the URL for time-critical SOC operations.

## Output

Only successful lookups with `abuseConfidenceScore === 100` appear in the generated email. The formatting retains Aptos, 11 pt, bold black emphasis, and a bordered, single-column Source IP table. Verify observations against firewall logs before sending.
