'use strict';

const express = require('express');
const path = require('node:path');
const net = require('node:net');
const crypto = require('node:crypto');
require('dotenv').config({ path: path.join(__dirname, '.env') });

const app = express();
const PORT = Number(process.env.PORT || 3000);
const HOST = process.env.HOST || (process.env.RENDER ? '0.0.0.0' : '127.0.0.1');
const MAX_UNIQUE_IPS_PER_BATCH = 300;
const MAX_RAW_IP_ENTRIES = 1500;
const MIN_MS_BETWEEN_ABUSEIPDB_REQUESTS = 1000;

app.disable('x-powered-by');

// Protect the entire application, including the reputation-checking API, with
// HTTP Basic Authentication. Credentials are supplied by environment variables.
function constantTimeEqual(a, b) {
  const left = Buffer.from(String(a));
  const right = Buffer.from(String(b));
  return left.length === right.length && crypto.timingSafeEqual(left, right);
}

app.use((req, res, next) => {
  const expectedUser = (process.env.APP_USERNAME || '').trim();
  const expectedPassword = process.env.APP_PASSWORD || '';
  if (!expectedUser || !expectedPassword || expectedPassword === 'CHANGE_THIS_TO_A_LONG_RANDOM_PASSWORD') {
    return res.status(503).type('text').send(
      'Application credentials are not configured. Set APP_USERNAME and APP_PASSWORD in your hosting environment, then restart/redeploy.'
    );
  }

  const header = req.get('authorization') || '';
  const match = header.match(/^Basic\s+([^\s]+)$/i);
  if (!match) {
    res.set('WWW-Authenticate', 'Basic realm="SOC IP Report Generator", charset="UTF-8"');
    return res.status(401).type('text').send('Authentication required. Sign in with your SOC IP Report Generator credentials.');
  }

  let suppliedUser = '';
  let suppliedPassword = '';
  try {
    const decoded = Buffer.from(match[1], 'base64').toString('utf8');
    const separator = decoded.indexOf(':');
    if (separator < 0) throw new Error('Invalid Basic authorization value');
    suppliedUser = decoded.slice(0, separator);
    suppliedPassword = decoded.slice(separator + 1);
  } catch {
    res.set('WWW-Authenticate', 'Basic realm="SOC IP Report Generator", charset="UTF-8"');
    return res.status(401).type('text').send('Invalid credentials.');
  }

  if (!constantTimeEqual(suppliedUser, expectedUser) || !constantTimeEqual(suppliedPassword, expectedPassword)) {
    res.set('WWW-Authenticate', 'Basic realm="SOC IP Report Generator", charset="UTF-8"');
    return res.status(401).type('text').send('Incorrect username or password.');
  }
  next();
});

app.use(express.json({ limit: '256kb' }));
app.use(express.static(path.join(__dirname, 'public'), {
  etag: false,
  setHeaders(res) {
    res.setHeader('Cache-Control', 'no-store');
  }
}));

app.get('/api/health', (_req, res) => {
  res.json({
    ok: true,
    abuseIpDbConfigured: Boolean(process.env.ABUSEIPDB_API_KEY && process.env.ABUSEIPDB_API_KEY.trim())
  });
});

let apiQueue = Promise.resolve();
let lastAbuseIpDbRequestAt = 0;

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

function queuedAbuseIpDbLookup(ip) {
  const task = apiQueue.then(async () => {
    const elapsed = Date.now() - lastAbuseIpDbRequestAt;
    if (lastAbuseIpDbRequestAt && elapsed < MIN_MS_BETWEEN_ABUSEIPDB_REQUESTS) {
      await sleep(MIN_MS_BETWEEN_ABUSEIPDB_REQUESTS - elapsed);
    }
    lastAbuseIpDbRequestAt = Date.now();
    return lookupAbuseIpDb(ip);
  });
  // Keep the queue usable even if a task fails.
  apiQueue = task.catch(() => undefined);
  return task;
}

async function lookupAbuseIpDb(ip) {
  const apiKey = (process.env.ABUSEIPDB_API_KEY || '').trim();
  const url = new URL('https://api.abuseipdb.com/api/v2/check');
  url.searchParams.set('ipAddress', ip);
  try {
    const response = await fetch(url, {
      method: 'GET',
      headers: {
        Key: apiKey,
        Accept: 'application/json'
      },
      signal: AbortSignal.timeout(15000)
    });
    let payload = {};
    try {
      payload = await response.json();
    } catch {
      payload = {};
    }

    if (!response.ok) {
      const apiMessage = Array.isArray(payload.errors)
        ? payload.errors.map(item => item.detail || item.title || item.message).filter(Boolean).join('; ')
        : '';
      return {
        ip,
        status: 'error',
        httpStatus: response.status,
        rateLimited: response.status === 429 || response.status === 402,
        error: apiMessage || `AbuseIPDB returned HTTP ${response.status}.`
      };
    }

    const data = payload.data;
    if (!data || !Number.isFinite(Number(data.abuseConfidenceScore))) {
      return { ip, status: 'error', error: 'AbuseIPDB returned an unexpected response.' };
    }

    return {
      ip,
      status: 'ok',
      score: Number(data.abuseConfidenceScore),
      countryCode: data.countryCode || '',
      country: data.countryName || data.countryCode || '',
      usageType: data.usageType || '',
      isp: data.isp || '',
      domain: data.domain || '',
      totalReports: Number.isFinite(Number(data.totalReports)) ? Number(data.totalReports) : 0,
      lastReportedAt: data.lastReportedAt || ''
    };
  } catch (error) {
    const timedOut = error && (error.name === 'TimeoutError' || error.name === 'AbortError');
    return {
      ip,
      status: 'error',
      error: timedOut ? 'AbuseIPDB request timed out.' : 'Could not connect to AbuseIPDB. Check the network connection.'
    };
  }
}

app.post('/api/check-reputation', async (req, res) => {
  if (!(process.env.ABUSEIPDB_API_KEY || '').trim()) {
    return res.status(503).json({
      error: 'AbuseIPDB API key is not configured. Add your rotated key to the .env file, then restart the app.'
    });
  }

  const submitted = req.body && req.body.ips;
  if (!Array.isArray(submitted) || submitted.length === 0) {
    return res.status(400).json({ error: 'Please upload a file containing IP addresses.' });
  }
  if (submitted.length > MAX_RAW_IP_ENTRIES) {
    return res.status(413).json({ error: `The upload contains more than ${MAX_RAW_IP_ENTRIES} entries. Split it into smaller files.` });
  }

  const cleaned = submitted
    .filter(value => typeof value === 'string' || typeof value === 'number')
    .map(value => String(value).trim())
    .filter(Boolean);
  const unique = [...new Set(cleaned)];
  const validIps = unique.filter(ip => net.isIP(ip) !== 0);
  const invalidCount = unique.length - validIps.length;
  const duplicatesRemoved = cleaned.length - unique.length;

  if (validIps.length === 0) {
    return res.status(400).json({ error: 'No valid IPv4 or IPv6 addresses were found in the uploaded file.' });
  }
  if (validIps.length > MAX_UNIQUE_IPS_PER_BATCH) {
    return res.status(413).json({
      error: `This upload contains ${validIps.length} unique valid IPs. The limit is ${MAX_UNIQUE_IPS_PER_BATCH} per batch; split the file into smaller files.`
    });
  }

  res.status(200);
  res.setHeader('Content-Type', 'application/x-ndjson; charset=utf-8');
  res.setHeader('Cache-Control', 'no-cache, no-transform');
  res.setHeader('X-Accel-Buffering', 'no');
  res.flushHeaders();

  const send = data => {
    if (!res.destroyed) res.write(`${JSON.stringify(data)}\n`);
  };

  send({
    type: 'start',
    total: validIps.length,
    invalidCount,
    duplicatesRemoved
  });

  let successful = 0;
  let failed = 0;
  let stopDueToQuota = false;

  for (let index = 0; index < validIps.length; index++) {
    if (res.destroyed) return;
    const ip = validIps[index];
    let result;

    if (stopDueToQuota) {
      result = {
        ip,
        status: 'error',
        error: 'Not checked because AbuseIPDB returned a quota/rate-limit response for an earlier IP.'
      };
    } else {
      result = await queuedAbuseIpDbLookup(ip);
      if (result.status === 'ok') successful++;
      else failed++;
      if (result.rateLimited) stopDueToQuota = true;
    }

    send({
      type: 'progress',
      processed: index + 1,
      total: validIps.length,
      result
    });
  }

  send({
    type: 'done',
    total: validIps.length,
    successful,
    failed,
    stoppedForQuota: stopDueToQuota
  });
  res.end();
});

app.use((err, _req, res, _next) => {
  if (res.headersSent) return res.end();
  const status = err && err.type === 'entity.too.large' ? 413 : 400;
  res.status(status).json({ error: status === 413 ? 'Request payload is too large.' : 'Invalid request.' });
});

app.listen(PORT, HOST, () => {
  console.log(`SOC IP Report Generator running at http://localhost:${PORT}`);
  if (!(process.env.ABUSEIPDB_API_KEY || '').trim()) {
    console.log('AbuseIPDB API key is not configured. Add it in the .env file or hosting environment.');
  }
  if (!(process.env.APP_USERNAME || '').trim() || !(process.env.APP_PASSWORD || '').trim()) {
    console.log('APP_USERNAME / APP_PASSWORD are required before the app can be used.');
  }
  console.log(`Listener host: ${HOST}`);
});
